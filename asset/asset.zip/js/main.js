
/* 
$('.card').mouseover(function () { 
    $('#captionCard').css({'opacity': '1', 'cursor':'pointer'});
    $('.card').css({'cursor':'pointer'});
});

$('.card').mouseleave(function () { 
    $('#captionCard').css({'opacity': '0', 'cursor':'pointer'});
}); */